/*
Navicat MySQL Data Transfer

Source Server         : MySql
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2016-11-27 22:22:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `responsedata`
-- ----------------------------
DROP TABLE IF EXISTS `responsedata`;
CREATE TABLE `responsedata` (
  `numid` int(11) NOT NULL,
  `temperature` int(11) DEFAULT NULL,
  `humidity` float DEFAULT NULL,
  `concentration` float DEFAULT NULL,
  PRIMARY KEY (`numid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of responsedata
-- ----------------------------
INSERT INTO `responsedata` VALUES ('1', '3', '55', '5');
INSERT INTO `responsedata` VALUES ('2', '4', '53', '3');
