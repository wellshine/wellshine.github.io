package service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import beans.ResponseData;

import jdbc.JdbcConn;

public class Service {
	
	private Connection dbconnection;
	private Statement st;
	private ResultSet rs;
	private String sql;
	private List list;
	private ResponseData rd;
	
	
	public List getResponseData(){
		list = new ArrayList();
		//��ȡ�������ݿ������
		dbconnection=JdbcConn.getConnection();
		try {
			st = (Statement)dbconnection.createStatement();
			
			
			sql="select responsedata.numid,responsedata.temperature,responsedata.humidity,responsedata.concentration"+ 
				     " from ResponseData" ;
			
			rs=st.executeQuery(sql);//ִ��sql
		
			
			//���������
			while(rs.next()){
				rd=new ResponseData();
				//ͨ��rsȡ�����ݿ��еĽ�����Ž�pf��
				rd.setNumid(rs.getInt("numid"));
				rd.setTemperature(rs.getInt("temperature"));
				rd.setHumidity(rs.getFloat("humidity"));
				rd.setConcentration(rs.getFloat("concentration"));
				
		
				

				list.add(rd);
			
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return list;
	}
	

}
